/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    // colors: {
    //   ebonyClay: "rgb(var(--color-ebonyClay) / <alpha-value>)",
    //   dodgerBlue: "rgb(var(--color-dodgerBlue) / <alpha-value>)",
    //   havelockBlue: "rgb(var(--color-havelockBlue) / <alpha-value>)",
    //   mediumPurple: "rgb(var(--color-mediumPurple) / <alpha-value>)",
    // },
    extend: {},
  },
  plugins: [],
};
