export const types = {

    //Types for Authentication
    login: '[Auth] login',
    logout: '[Auth] logout',

    //Types for UI
    uiSetError: '[UI] Set Error',
    uiRemoveError: '[UI] Remove Error',

}